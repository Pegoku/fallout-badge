G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,10.0.4*
G04 #@! TF.CreationDate,2026-07-02T13:06:01+08:00*
G04 #@! TF.ProjectId,badgePCB,62616467-6550-4434-922e-6b696361645f,rev?*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 10.0.4) date 2026-07-02 13:06:01*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 APERTURE END LIST*
M02*
